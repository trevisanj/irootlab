%> @ingroup globals usercomm
%> @file
%> @brief Clears the @c PROGRESS global
function progress_reset()
global PROGRESS;
PROGRESS = [];
