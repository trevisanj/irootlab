Wine dataset from UCI repository - <a href=http://archive.ics.uci.edu/ml/datasets/Wine>http://archive.ics.uci.edu/ml/datasets/Wine</a>; no=178; nf=13; nc=3
