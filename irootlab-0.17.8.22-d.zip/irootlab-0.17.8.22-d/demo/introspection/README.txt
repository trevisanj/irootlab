Self-checking of IRootLab directory
