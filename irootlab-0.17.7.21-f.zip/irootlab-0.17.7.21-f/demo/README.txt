The following examples demonstrate the use of IRootLab library to analyse data and generate figures. The directories are roughly organized by dataset.
