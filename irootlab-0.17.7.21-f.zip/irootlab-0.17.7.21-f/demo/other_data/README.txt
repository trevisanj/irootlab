Others and other data
