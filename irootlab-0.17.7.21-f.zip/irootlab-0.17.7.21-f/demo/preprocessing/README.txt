Pre-processing demos
