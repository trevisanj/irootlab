%> SODATAITEM generated as output of an UnderSel process (Undersampling Selection)
%>
%> Explicitly declared to be seen by a report_soitem_underselout.
%> Update (17/06/2013) Actually there is no report associated specifically with 
%> soitem_underselout. This class is unnecessary at the moment, but OK.
classdef soitem_undersel < soitem_sostagechoice
end