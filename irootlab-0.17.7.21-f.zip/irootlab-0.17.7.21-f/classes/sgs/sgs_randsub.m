%> @brief Random Sub-sampling
%>
%>
%> @sa sgs_randsub_base, uip_sgs_randsub_base.m, uip_sgs_randsub.m
classdef sgs_randsub < sgs_randsub_base
    methods
        function o = sgs_randsub(o)
            o.classtitle = 'Random Sub-sampling';
        end;
    end;
end