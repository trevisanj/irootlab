%>@file
%>@brief Current IRootLab version
%> @ingroup usercomm idata
function s = irootlab_version()
s = '0.17.7.21-f';
