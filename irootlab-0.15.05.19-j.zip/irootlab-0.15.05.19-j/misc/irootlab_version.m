%>@file
%>@brief Current IRootLab version
%> @ingroup usercomm idata
function s = irootlab_version()
s = '0.15.05.19-j';
