%>@brief Loads sample data userdata_nc2nf2.txt
%>@file
%>@ingroup demo sampledata
%
%> @return A dataset
function varargout = load_data_userdata_nc2nf2()
varargout = {load_sampledata('userdata_nc2nf2.txt', nargout <= 0)};




