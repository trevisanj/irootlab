Syrian Hamster Embryo (SHE) assay dataset, 2 class levels: &lt;chemical&gt;|&lt;transformation&gt;; 5 * 2 = 10 classes; no=600; nf=58
