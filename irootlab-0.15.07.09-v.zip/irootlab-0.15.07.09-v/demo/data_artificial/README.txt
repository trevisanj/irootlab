2-feature dataset created using <i>gendata</i>. Most demos here show 2-dimensional classification regions
