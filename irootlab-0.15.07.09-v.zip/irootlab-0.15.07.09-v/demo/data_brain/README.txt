Ketan's brain cancer dataset, no=439, nf=235, 3 classes
