%>@file
%>@brief Current IRootLab version
%> @ingroup usercomm idata
function s = irootlab_version()
s = '0.15.07.09-v';
