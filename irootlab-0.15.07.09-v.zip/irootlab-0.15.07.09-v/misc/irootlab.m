%> @file
%> @ingroup guigroup usercomm
%> @brief Calls the IRootLab main GUI
irootlabgui;
