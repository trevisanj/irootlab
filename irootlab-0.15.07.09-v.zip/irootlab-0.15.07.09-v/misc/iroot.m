%> @file
%> @ingroup guigroup compat
%> @brief Calls the IRootLab main GUI
irootlabgui;
