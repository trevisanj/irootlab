%> @ingroup globals codegen
%> @file
%> @brief Clears the @c IRCODE global
function ircode_reset()
global IRCODE;
IRCODE = [];
