%> @file
%> @ingroup guigroup
%> @brief Calls the main GUI
irootlabgui;